# Pennant Example System

This repository contains a minimal TypeScript system that simulates a set of recurring tasks and a lightweight event observer. It is intentionally small, but it can be installed, built, and run end-to-end with npm.

## Getting started

```bash
npm install
npm run build
npm start
```

The `start` script runs Node against the compiled output in `dist/`. For faster iteration you can also run `npm run dev`, which executes the TypeScript entrypoint directly via `ts-node` (no build step required).

Press `Ctrl+C` to stop the process.

## Project structure

- `src/system.ts` – Tiny scheduler that manages recurring tasks and emits events.
- `src/tasks.ts` – Example tasks (heartbeat logging and random value emitter).
- `src/index.ts` – Bootstraps the system, attaches an observer, and handles shutdown.

Feel free to add new tasks or wire the system up to other services.
