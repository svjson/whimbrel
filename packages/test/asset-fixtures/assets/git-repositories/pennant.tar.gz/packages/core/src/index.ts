export type Environment = 'development' | 'staging' | 'production';

export interface TargetingRule {
  attribute: string;
  equals: string;
}

export interface FeatureFlagDefinition {
  key: string;
  description: string;
  enabled: boolean;
  rolloutPercentage: number; // 0-100
  environments: Environment[];
  tags: string[];
  targetingRules?: TargetingRule[];
}

export interface EvaluationContext {
  userId: string;
  environment: Environment;
  attributes?: Record<string, string>;
}

export type EvaluationReason =
  | 'flag_missing'
  | 'flag_disabled'
  | 'environment_mismatch'
  | 'attribute_mismatch'
  | 'outside_rollout'
  | 'within_rollout';

export interface FlagEvaluation {
  key: string;
  enabled: boolean;
  variant: 'on' | 'off';
  reason: EvaluationReason;
}

const clampPercentage = (value: number) => Math.min(100, Math.max(0, value));

const deterministicBucket = (seed: string) => {
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return hash % 100;
};

export class FlagRegistry {
  private readonly flags = new Map<string, FeatureFlagDefinition>();

  constructor(initialFlags: FeatureFlagDefinition[] = []) {
    initialFlags.forEach((flag) => this.flags.set(flag.key, normalizeFlag(flag)));
  }

  upsert(flag: FeatureFlagDefinition) {
    this.flags.set(flag.key, normalizeFlag(flag));
  }

  listFlags() {
    return Array.from(this.flags.values());
  }

  getFlag(key: string) {
    return this.flags.get(key);
  }

  evaluateFlag(key: string, ctx: EvaluationContext): FlagEvaluation {
    const flag = this.flags.get(key);
    if (!flag) {
      return { key, enabled: false, variant: 'off', reason: 'flag_missing' };
    }

    if (!flag.enabled) {
      return { key, enabled: false, variant: 'off', reason: 'flag_disabled' };
    }

    if (!flag.environments.includes(ctx.environment)) {
      return { key, enabled: false, variant: 'off', reason: 'environment_mismatch' };
    }

    if (flag.targetingRules && flag.targetingRules.length > 0) {
      const attrs = ctx.attributes ?? {};
      const matchesAll = flag.targetingRules.every((rule) => attrs[rule.attribute] === rule.equals);
      if (!matchesAll) {
        return { key, enabled: false, variant: 'off', reason: 'attribute_mismatch' };
      }
    }

    const bucketSeed = `${flag.key}:${ctx.userId}`;
    const bucket = deterministicBucket(bucketSeed);
    const threshold = clampPercentage(flag.rolloutPercentage);
    const isEnabled = bucket < threshold;
    return {
      key,
      enabled: isEnabled,
      variant: isEnabled ? 'on' : 'off',
      reason: isEnabled ? 'within_rollout' : 'outside_rollout',
    };
  }

  evaluateAll(ctx: EvaluationContext) {
    return this.listFlags().map((flag) => this.evaluateFlag(flag.key, ctx));
  }
}

const normalizeFlag = (flag: FeatureFlagDefinition): FeatureFlagDefinition => ({
  ...flag,
  rolloutPercentage: clampPercentage(flag.rolloutPercentage),
});

export const demoFlags: FeatureFlagDefinition[] = [
  {
    key: 'onboarding-checklist',
    description: 'Gate UI for the onboarding checklist experiment.',
    enabled: true,
    rolloutPercentage: 100,
    environments: ['development', 'staging', 'production'],
    tags: ['ui', 'experiment'],
  },
  {
    key: 'pro-search',
    description: 'Unlocks the advanced search filters for pro tier customers.',
    enabled: true,
    rolloutPercentage: 60,
    environments: ['staging', 'production'],
    targetingRules: [{ attribute: 'plan', equals: 'pro' }],
    tags: ['search', 'revenue'],
  },
  {
    key: 'beta-api-v2',
    description: 'Exposes the beta API endpoints.',
    enabled: false,
    rolloutPercentage: 10,
    environments: ['development'],
    tags: ['api'],
  },
];

export const createDefaultRegistry = () => new FlagRegistry(demoFlags);
