import cors from "cors";
import express from "express";
import type { EvaluationContext } from "@pennant/core";
import { createDefaultRegistry } from "@pennant/core";

const app = express();
const registry = createDefaultRegistry();
const port = Number(process.env.PORT ?? 4000);

app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

app.get("/flags", (_req, res) => {
  res.json({ flags: registry.listFlags() });
});

app.post("/evaluate", (req, res) => {
  const { context, keys } = req.body ?? {};
  const normalizedContext = normalizeContext(context);
  if (!normalizedContext.ok) {
    res.status(400).json({ error: normalizedContext.error });
    return;
  }

  const requestedKeys: string[] | undefined = Array.isArray(keys)
    ? keys.filter((key) => typeof key === "string")
    : undefined;

  const decisions = (
    requestedKeys ?? registry.listFlags().map((flag) => flag.key)
  ).map((key) => registry.evaluateFlag(key, normalizedContext.value));

  res.json({ decisions });
});

app.listen(port, () => {
  console.log(`Pennant backend listening on http://localhost:${port}`);
});

const ENVIRONMENTS = new Set(["development", "staging", "production"]);

const normalizeContext = (
  context: unknown,
): { ok: true; value: EvaluationContext } | { ok: false; error: string } => {
  if (typeof context !== "object" || context === null) {
    return { ok: false, error: "context must be provided" };
  }

  const { userId, environment, attributes } = context as Record<
    string,
    unknown
  >;
  if (typeof userId !== "string" || userId.trim() === "") {
    return { ok: false, error: "userId is required" };
  }

  if (typeof environment !== "string" || !ENVIRONMENTS.has(environment)) {
    return {
      ok: false,
      error: "environment must be development, staging, or production",
    };
  }

  const safeAttributes: Record<string, string> | undefined =
    attributes && typeof attributes === "object"
      ? Object.entries(attributes as Record<string, unknown>)
          .filter(
            (entry): entry is [string, string] => typeof entry[1] === "string",
          )
          .reduce<Record<string, string>>((acc, [key, value]) => {
            acc[key] = value;
            return acc;
          }, {})
      : undefined;

  return {
    ok: true,
    value: {
      userId,
      environment: environment as EvaluationContext["environment"],
      attributes: safeAttributes as Record<string, string>,
    },
  };
};
