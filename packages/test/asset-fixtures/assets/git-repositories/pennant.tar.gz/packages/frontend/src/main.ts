import './style.css';
import type {
  EvaluationContext,
  FeatureFlagDefinition,
  FlagEvaluation,
} from '@pennant/core';

const API_BASE = (import.meta.env.VITE_API_URL as string | undefined) ?? 'http://localhost:4000';

const app = document.querySelector<HTMLDivElement>('#app');
if (!app) {
  throw new Error('Missing #app container');
}

app.innerHTML = `
  <header>
    <h1>Pennant Flags</h1>
    <p>A tiny UI to inspect and evaluate feature flags.</p>
  </header>
  <main>
    <section>
      <h2>Defined flags</h2>
      <div id="flags"></div>
    </section>
    <section>
      <h2>Evaluate flags</h2>
      <form id="eval-form">
        <label>
          User ID
          <input type="text" name="userId" required placeholder="user-123" />
        </label>
        <label>
          Environment
          <select name="environment">
            <option value="development">development</option>
            <option value="staging">staging</option>
            <option value="production">production</option>
          </select>
        </label>
        <label>
          Plan
          <select name="plan">
            <option value="free">free</option>
            <option value="pro">pro</option>
          </select>
        </label>
        <button type="submit">Evaluate</button>
      </form>
      <div id="results" aria-live="polite"></div>
    </section>
  </main>
`;

const flagsContainer = document.querySelector<HTMLDivElement>('#flags');
const resultsContainer = document.querySelector<HTMLDivElement>('#results');
const evalForm = document.querySelector<HTMLFormElement>('#eval-form');

const renderFlags = (flags: FeatureFlagDefinition[]) => {
  if (!flagsContainer) return;
  if (flags.length === 0) {
    flagsContainer.innerHTML = '<p>No flags registered.</p>';
    return;
  }

  const items = flags
    .map(
      (flag) => `
        <article>
          <header>
            <strong>${flag.key}</strong>
            <span class="tag">${flag.enabled ? 'enabled' : 'disabled'}</span>
          </header>
          <p>${flag.description}</p>
          <dl>
            <div><dt>Rollout</dt><dd>${flag.rolloutPercentage}%</dd></div>
            <div><dt>Environments</dt><dd>${flag.environments.join(', ')}</dd></div>
            <div><dt>Tags</dt><dd>${flag.tags.join(', ') || '—'}</dd></div>
          </dl>
        </article>
      `
    )
    .join('');

  flagsContainer.innerHTML = items;
};

const renderResults = (decisions: FlagEvaluation[]) => {
  if (!resultsContainer) return;
  if (decisions.length === 0) {
    resultsContainer.innerHTML = '<p>No decisions.</p>';
    return;
  }

  resultsContainer.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Flag</th>
          <th>State</th>
          <th>Reason</th>
        </tr>
      </thead>
      <tbody>
        ${decisions
          .map(
            (decision) => `
              <tr>
                <td>${decision.key}</td>
                <td class="${decision.enabled ? 'on' : 'off'}">${decision.variant}</td>
                <td>${decision.reason}</td>
              </tr>
            `
          )
          .join('')}
      </tbody>
    </table>
  `;
};

const fetchFlags = async () => {
  const response = await fetch(`${API_BASE}/flags`);
  const payload = (await response.json()) as { flags: FeatureFlagDefinition[] };
  renderFlags(payload.flags);
};

const evaluateFlags = async (context: EvaluationContext) => {
  const response = await fetch(`${API_BASE}/evaluate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ context }),
  });
  const payload = (await response.json()) as { decisions: FlagEvaluation[] };
  renderResults(payload.decisions);
};

fetchFlags().catch((error) => {
  console.error('Failed to load flags', error);
  if (flagsContainer) {
    flagsContainer.innerHTML = '<p class="error">Failed to load flags. Is the backend running?</p>';
  }
});

if (evalForm) {
  evalForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const formData = new FormData(evalForm);
    const context: EvaluationContext = {
      userId: String(formData.get('userId') ?? ''),
      environment: (formData.get('environment') as EvaluationContext['environment']) ?? 'development',
      attributes: {
        plan: String(formData.get('plan') ?? 'free'),
      },
    };
    evaluateFlags(context).catch((error) => {
      console.error('Evaluation failed', error);
      if (resultsContainer) {
        resultsContainer.innerHTML = '<p class="error">Evaluation failed.</p>';
      }
    });
  });
}
